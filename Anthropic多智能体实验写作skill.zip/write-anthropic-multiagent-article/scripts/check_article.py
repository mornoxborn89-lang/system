#!/usr/bin/env python3
"""Check hard constraints for the Anthropic multiagent WeChat article."""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path


TITLE = "Anthropic多智能体实验出现“地盘争夺”，增加Agent为什么没有提高协作效率？"
OFFICIAL_URL = "https://www.anthropic.com/research/multiagent-systems"
TECHCRUNCH_URL = (
    "https://techcrunch.com/2026/08/13/"
    "anthropic-set-ai-agents-loose-on-the-same-task-they-started-a-turf-war/"
)

CLICHES = {
    r"不是.{0,40}而是": "疑似翻案句式",
    r"并非.{0,40}而是": "疑似翻案句式",
    r"你以为.{0,40}其实": "疑似翻案句式",
    r"先说结论|说白了|说穿了": "模板化路标",
    r"赋能|重塑|颠覆|底层逻辑|时代浪潮|生态闭环|重新定义": "商业或模型惯用词",
}

REQUIRED_TOPICS = {
    "漏洞搜索": r"漏洞",
    "软件协作": r"PR|pull request|代码冲突|合并",
    "价格串通": r"串通|价格联盟|价格下限|定价游戏",
    "地盘争夺": r"地盘争夺|目标冲突|冲突目标",
    "系统性失败": r"系统性|集体犯错|相似决策|同质",
}


def line_number(text: str, offset: int) -> int:
    return text.count("\n", 0, offset) + 1


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("draft", type=Path)
    args = parser.parse_args()

    if not args.draft.is_file():
        print(f"ERROR: file not found: {args.draft}")
        return 2

    text = args.draft.read_text(encoding="utf-8")
    errors: list[str] = []
    warnings: list[str] = []

    if not text.strip():
        errors.append("稿件为空")
    if TITLE not in text:
        errors.append("未使用用户确定的固定标题")
    if re.search(r"\bTODO\b|\[待补|待核实|占位", text, re.I):
        errors.append("仍有 TODO、待补或占位内容")

    if "266" in text and "21" in text:
        caveat = re.search(
            r"(?:不能|不可|无法|不宜).{0,24}(?:直接|简单).{0,12}(?:比较|对比)|"
            r"(?:搜索范围|范围|token|预算).{0,80}(?:不同|差异)",
            text,
            re.I | re.S,
        )
        if not caveat:
            errors.append("出现 266 与 21，但没有说明两组不能直接比较")
        if not re.search(r"2700\s*万|27\s*(?:million|m)\b", text, re.I):
            warnings.append("出现 266 与 21，但未交代协调方案约 2700 万 token")
        if not re.search(r"650\s*万|6\.5\s*(?:million|m)\b", text, re.I):
            warnings.append("出现 266 与 21，但未交代独立方案约 650 万 token")

    if re.search(r"266.{0,30}(?:是|为).{0,20}21.{0,20}(?:倍|十几倍)", text, re.S):
        errors.append("把 266 与 21 写成了直接性能倍数")

    if OFFICIAL_URL not in text:
        errors.append("来源中缺少 Anthropic 官方研究链接")
    if TECHCRUNCH_URL not in text:
        warnings.append("来源中缺少用户指定的 TechCrunch 报道链接")

    chinese_chars = len(re.findall(r"[\u3400-\u9fff]", text))
    url_count = len(re.findall(r"https?://", text))
    has_sources_heading = bool(
        re.search(r"^#{1,4}\s*(资料来源|参考资料|参考来源|来源)\s*$", text, re.M)
    )
    if chinese_chars >= 1200:
        if not has_sources_heading:
            errors.append("长篇现实稿缺少来源章节")
        if url_count < 3:
            warnings.append("长篇稿件来源少于 3 个链接")

    for label, pattern in REQUIRED_TOPICS.items():
        if not re.search(pattern, text, re.I):
            warnings.append(f"未发现“{label}”相关内容，检查完整实验解读是否缺项")

    if "—" in text or "–" in text:
        warnings.append("发现破折号，改成普通句子")

    for pattern, label in CLICHES.items():
        for match in re.finditer(pattern, text):
            snippet = match.group(0).replace("\n", " ")
            warnings.append(
                f"第 {line_number(text, match.start())} 行：{label}：{snippet[:60]}"
            )

    print(f"Chinese characters: {chinese_chars}")
    print(f"Source links: {url_count}")
    for item in errors:
        print(f"ERROR: {item}")
    for item in warnings:
        print(f"WARN: {item}")
    if not errors and not warnings:
        print("OK: no issues found")

    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
