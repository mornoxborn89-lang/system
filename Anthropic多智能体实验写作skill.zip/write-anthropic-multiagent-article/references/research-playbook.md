# 联网研究与事实核验

## 每次写作都重新检索

这项研究发布于 2026 年 8 月，媒体报道、后续回应、模型名称和企业实践可能继续变化。每次开始写作时记录当前日期，重新打开来源，核对页面是否更新。

## 起始来源

1. [Anthropic 官方研究《Patterns and problems in emerging multiagent systems》](https://www.anthropic.com/research/multiagent-systems)
2. [TechCrunch 报道《Anthropic set AI agents loose on the same task. They started a turf war.》](https://techcrunch.com/2026/08/13/anthropic-set-ai-agents-loose-on-the-same-task-they-started-a-turf-war/)

官方页面是实验设置、图表、数字和研究结论的主要依据。TechCrunch 用于说明热点传播、补充采访语境和识别外部问题。报道中涉及其他机构、真实事件或 prompt injection 的段落，需要找到它引用的原始来源，不能直接算作 Anthropic 实验结果。

## 来源顺序

1. Anthropic 官方研究、图表、相关论文和官方说明。
2. 被文章提及的其他实验室、会议或项目的原始发布。
3. 有编辑审核并直接链接原始材料的科技媒体。
4. 研究者公开评论，只用于呈现有身份的个人观点。

社交平台帖子和搜索摘要只用于发现线索。找不到原始出处的数字、引语和案例不进入正文。

## 建议检索式

```text
site:anthropic.com/research multiagent systems coordination vulnerabilities 266 21
site:anthropic.com/research multiagent turf war Bertrand pricing hidden profile
Anthropic multiagent systems August 13 2026 analysis
Anthropic multiagent systems enterprise governance permissions audit
Patterns and problems in emerging multiagent systems follow-up
```

搜索中文报道时，继续回到英文原文核对模型名、实验条件和数字。不要把不同媒体沿用的同一段转述当成多个独立来源。

## 证据账本

内部至少记录以下字段。

| 具体事实 | 原始来源 | 发布日期 | 实验条件 | 支撑的判断 | 限制或冲突 |
| --- | --- | --- | --- | --- | --- |
| 45 个协调智能体找到 266 个漏洞 | Anthropic 官方研究 | 2026-08-13 | 15 个项目、共享论坛、约 2700 万 token | 可并行任务可形成分工 | 与独立方案范围和预算不同 |

长稿至少准备五件具体材料，并确保覆盖以下不同实验中的至少四类。

- 漏洞搜索
- 共享软件项目
- 相似决策或系统资源拥塞
- 模拟价格串通
- 信息信任或隐藏信息
- 冲突目标与“地盘争夺”

## 数字核验

记录数字时同时记下对象、模型、样本量、运行时间、token 预算和比较基线。正文可以删去不影响理解的细节，不能删去会改变结论的比较条件。

特别检查：

- 266 个漏洞对应哪一种模型和哪一种协调配置。
- 21 个漏洞对应怎样分配搜索位置，以及 token 预算是多少。
- “约一半在核心目录之外”和“只有 12 个重合”的准确表述。
- 软件实验的运行时长、Agent 数量范围、PR 指标和模型代际。
- 定价游戏的 Agent 数量、通信条件和目标函数。
- 冲突目标实验的 Agent 数量、目标语言、样本量和不同解决方式。

图表中的近似值写“约”。只有正文或图注明确给出精确值时才写成精确数字。

## 日期与时区

Anthropic 页面标注 2026 年 8 月 13 日。涉及“北京时间 8 月 14 日前后”时，确认对应来源的发布时间、时区和换算，不把媒体发布日期当成实验发生日期。

## 引语与归因

- 直接引语逐字回到原文核对，总量保持很少。
- Anthropic 的解释写成“研究团队认为”或紧跟官方来源。
- TechCrunch 的推测写成媒体分析，不能省略归因。
- 作者根据实验提出的企业建议写成本文判断。
- 来源出现冲突时，解释口径差异，不选择更惊人的数字。

## 开稿条件

满足以下条件后才能写 1200 字以上的文章。

- 已打开并核对官方研究全文。
- 已核对用户指定的 TechCrunch 报道。
- 至少找到一个补充来源。
- 至少五件具体材料进入证据账本。
- 266 与 21 的比较限制已经写清。
- 能用一句话解释哪些任务从多智能体协作中获益，哪些条件导致协调失败。

公开资料不足时继续研究。仍无法核实就缩小表述或缩短文章，不用常识推演和假案例补足篇幅。
